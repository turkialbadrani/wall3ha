
import 'dart:convert';
import 'package:http/http.dart' as http;

class OpenAIHelper {
  static const String _apiKey = 'sk-...'; // 🔐 ضع مفتاحك هنا
  static const String _apiUrl = 'https://api.openai.com/v1/chat/completions';
  static const String _model = 'gpt-4o'; // 🎯 موديل GPT-4o

  static Future<String> generateText(String prompt) async {
    try {
      final response = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          'Authorization': 'Bearer \$_apiKey',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          "model": _model,
          "messages": [
            {"role": "system", "content": "أنت مساعد ذكي ومحترف."},
            {"role": "user", "content": prompt}
          ]
        }),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['choices'][0]['message']['content'].toString().trim();
      } else {
        return "⚠️ فشل في الاتصال بـ GPT (${response.statusCode})";
      }
    } catch (e) {
      return "❌ خطأ أثناء استدعاء GPT: \$e";
    }
  }
}
