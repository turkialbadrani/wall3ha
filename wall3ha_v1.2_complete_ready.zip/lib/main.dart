
import 'package:flutter/material.dart';
import 'screens/v1_2/occasion_message_screen_v12.dart';
import 'screens/v1_2/understand_it_screen_v12.dart';
import 'screens/v1_2/trend_discussion_screen_v12.dart';
import 'screens/v1_2/smart_reply_screen_v12.dart';
import 'screens/v1_2/about_screen_v12.dart';

void main() {
  runApp(Wall3haApp());
}

class Wall3haApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ولّعها V1.2',
      theme: ThemeData.dark(),
      debugShowCheckedModeBanner: false,
      home: HomeNavigation(),
    );
  }
}

class HomeNavigation extends StatefulWidget {
  @override
  _HomeNavigationState createState() => _HomeNavigationState();
}

class _HomeNavigationState extends State<HomeNavigation> {
  int _selectedIndex = 0;

  final List<Widget> _widgetOptions = <Widget>[
    SmartReplyScreenV12(),
    OccasionMessageScreenV12(),
    UnderstandItScreenV12(),
    TrendDiscussionScreenV12(),
    AboutScreenV12(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _widgetOptions[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.amber,
        unselectedItemColor: Colors.grey,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.message),
            label: 'الرد السريع',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.card_giftcard),
            label: 'المناسبات',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.psychology),
            label: 'افهمها صح',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.whatshot),
            label: 'اشعلها'),
          BottomNavigationBarItem(
            icon: Icon(Icons.info_outline),
            label: 'حول'
          ),
        ],
      ),
    );
  }
}
