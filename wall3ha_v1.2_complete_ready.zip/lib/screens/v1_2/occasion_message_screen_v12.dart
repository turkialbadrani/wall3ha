
import 'package:flutter/material.dart';

class OccasionMessageScreenV12 extends StatefulWidget {
  const OccasionMessageScreenV12({super.key});

  @override
  State<OccasionMessageScreenV12> createState() => _OccasionMessageScreenV12State();
}

class _OccasionMessageScreenV12State extends State<OccasionMessageScreenV12> {
  final List<String> occasions = ['عيد الفطر', 'رمضان', 'اليوم الوطني', 'زواج', 'تخرج'];
  final List<String> tones = ['رسمي', 'عفوي', 'شاعري'];
  final List<String> dialects = ['نجدية', 'حجازية', 'خليجية'];

  String? selectedOccasion;
  String? selectedTone;
  String? selectedDialect;
  String? generatedMessage;

  void generateMessage() {
    // هذا الجزء سيتم ربطه لاحقًا بـ GPT
    setState(() {
      generatedMessage =
          "🎉 تهنئة بـ '$selectedOccasion' بأسلوب '$selectedTone' وباللهجة '$selectedDialect'...";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("رسائل المناسبات")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: selectedOccasion,
              decoration: const InputDecoration(labelText: "اختر المناسبة"),
              items: occasions.map((occasion) {
                return DropdownMenuItem(value: occasion, child: Text(occasion));
              }).toList(),
              onChanged: (value) => setState(() => selectedOccasion = value),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: selectedTone,
              decoration: const InputDecoration(labelText: "اختر الأسلوب"),
              items: tones.map((tone) {
                return DropdownMenuItem(value: tone, child: Text(tone));
              }).toList(),
              onChanged: (value) => setState(() => selectedTone = value),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: selectedDialect,
              decoration: const InputDecoration(labelText: "اختر اللهجة"),
              items: dialects.map((dialect) {
                return DropdownMenuItem(value: dialect, child: Text(dialect));
              }).toList(),
              onChanged: (value) => setState(() => selectedDialect = value),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: (selectedOccasion != null &&
                      selectedTone != null &&
                      selectedDialect != null)
                  ? generateMessage
                  : null,
              child: const Text("ولّعها 🎉"),
            ),
            const SizedBox(height: 24),
            if (generatedMessage != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey),
                ),
                child: SelectableText(generatedMessage!),
              ),
          ],
        ),
      ),
    );
  }
}
