
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SmartReplyScreenV12 extends StatefulWidget {
  @override
  _SmartReplyScreenV12State createState() => _SmartReplyScreenV12State();
}

class _SmartReplyScreenV12State extends State<SmartReplyScreenV12> {
  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _customStyleController = TextEditingController();
  final TextEditingController _customDialectController = TextEditingController();

  String selectedStyle = '';
  String selectedDialect = '';

  String response = '';
  bool isLoading = false;
  bool showCustomStyleField = false;
  bool showCustomDialectField = false;

  final List<String> styles = ['ساخر', 'حزين', 'فلسفي', 'رومانسي'];
  final List<String> dialects = ['سعودي', 'مصري', 'سوداني', 'مغربي'];

  Future<void> _handleReply() async {
    setState(() => isLoading = true);

    final message = _messageController.text.trim();
    final style = showCustomStyleField ? _customStyleController.text.trim() : selectedStyle;
    final dialect = showCustomDialectField ? _customDialectController.text.trim() : selectedDialect;

    final prompt = "رد على الرسالة التالية باللهجة: \"$dialect\"، وبأسلوب: \"$style\".\n"
                   "الرسالة: \"$message\"\n"
                   "\nالشروط:\n"
                   "- لا تستخدم شعر ولا سجع.\n"
                   "- لا تكرر نص الرسالة.\n"
                   "- لا تدخل ألفاظ دينية.\n"
                   "- فقط أرسل الرد المناسب بدون تمهيد أو تحليل.\n"
                   "- خلك لبق، ذكي، وردك يعكس الأسلوب المطلوب.";

    try {
      final res = await http.post(
        Uri.parse('https://api.openai.com/v1/chat/completions'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer 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'
        },
        body: jsonEncode({
          'model': 'gpt-4',
          'messages': [{'role': 'user', 'content': prompt}],
          'temperature': 0.7
        }),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(utf8.decode(res.bodyBytes));
        final content = data['choices'][0]['message']['content'];
        setState(() {
          response = content;
        });
      } else {
        setState(() {
          response = 'فشل الاتصال بـ GPT: حالة ' + res.statusCode.toString();
        });
      }
    } catch (e) {
      setState(() {
        response = 'حدث خطأ أثناء الاتصال: \$e';
      });
    }

    setState(() => isLoading = false);
  }

  Widget _buildChips(List<String> options, String selected, Function(String) onSelected,
      String customLabel, bool showCustom, Function(bool) toggleCustom, TextEditingController controller) {
    return Wrap(
      spacing: 8.0,
      children: [
        ...options.map((option) => ChoiceChip(
              label: Text(option),
              selected: selected == option,
              onSelected: (_) {
                toggleCustom(false);
                onSelected(option);
              },
            )),
        ChoiceChip(
          label: SizedBox(
            width: 120,
            child: showCustom
                ? TextField(
                    controller: controller,
                    autofocus: true,
                    decoration: InputDecoration.collapsed(hintText: customLabel),
                    style: TextStyle(color: Colors.white),
                    onChanged: onSelected,
                  )
                : Text('إدخال جديد'),
          ),
          selected: showCustom,
          onSelected: (_) {
            toggleCustom(true);
            controller.clear();
            onSelected('');
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('🔥 الرد السريع')),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: [
              Text('📩 الرسالة المستلمة:'),
              TextField(
                controller: _messageController,
                maxLines: null,
                decoration: InputDecoration(
                  hintText: 'اكتب الرسالة هنا...',
                  filled: true,
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 24),
              Text('🧠 اختر الأسلوب أو أدخل واحد خاص:'),
              _buildChips(styles, selectedStyle, (val) => setState(() => selectedStyle = val),
                  'أدخل أسلوب جديد (اختياري)', showCustomStyleField,
                  (val) => setState(() => showCustomStyleField = val), _customStyleController),
              SizedBox(height: 24),
              Text('🌍 اختر اللهجة:'),
              _buildChips(dialects, selectedDialect, (val) => setState(() => selectedDialect = val),
                  'أدخل لهجة جديدة (اختياري)', showCustomDialectField,
                  (val) => setState(() => showCustomDialectField = val), _customDialectController),
              SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: isLoading ? null : _handleReply,
                icon: Icon(Icons.bolt),
                label: Text('حلل ورد 🔥⚡'),
              ),
              SizedBox(height: 24),
              if (isLoading) Center(child: CircularProgressIndicator()),
              if (!isLoading && response.isNotEmpty)
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey[900],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(response),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
