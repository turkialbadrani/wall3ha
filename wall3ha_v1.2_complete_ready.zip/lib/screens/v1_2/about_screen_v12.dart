
import 'package:flutter/material.dart';

class AboutScreenV12 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('حول التطبيق'),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('🔥 ولّعها', style: Theme.of(context).textTheme.headlineSmall),
              SizedBox(height: 12),
              Text(
                'تطبيق ذكي يساعدك ترد على الرسائل، تشعل النقاشات، وتفهم وش يدور حولك… بأسلوب لبق، ذكي، ويشبهك.',
              ),
              SizedBox(height: 24),
              Text('📦 النسخة: V1.2'),
              SizedBox(height: 12),
              Text('📩 للتواصل:'),
              SelectableText('youremail@example.com', style: TextStyle(color: Colors.blueAccent)),
              Spacer(),
              Text('© 2024 جميع الحقوق محفوظة'),
            ],
          ),
        ),
      ),
    );
  }
}
