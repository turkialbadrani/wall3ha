
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(Wall3haApp());

class Wall3haApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '🔥 ولّعها',
      theme: ThemeData.dark(),
      home: SmartReplyScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SmartReplyScreen extends StatefulWidget {
  @override
  _SmartReplyScreenState createState() => _SmartReplyScreenState();
}

class _SmartReplyScreenState extends State<SmartReplyScreen> {
  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _customStyleController = TextEditingController();
  final TextEditingController _customDialectController = TextEditingController();

  String selectedStyle = '';
  String selectedDialect = '';

  String response = '';
  bool isLoading = false;
  bool showCustomStyleField = false;
  bool showCustomDialectField = false;
  final FocusNode customFocus = FocusNode();

  final List<String> styles = ['ساخر', 'حزين', 'فلسفي', 'رومانسي'];
  final List<String> dialects = ['سعودي', 'مصري', 'سوداني', 'مغربي'];

  Future<void> _handleReply() async {
    setState(() => isLoading = true);

    final message = _messageController.text.trim();
    final style = showCustomStyleField ? _customStyleController.text.trim() : selectedStyle;
    final dialect = showCustomDialectField ? _customDialectController.text.trim() : selectedDialect;

    final prompt = """
رد مباشرة على الرسالة التالية باللهجة: "$dialect"، وبأسلوب: "$style".
الرسالة: "$message"

الشروط:
- لا تستخدم شعر ولا سجع.
- لا تدخل ألفاظ دينية.
- لا تكرر نص الرسالة.
- لا تقدم أي تحليل أو شرح أو تفسير.
- فقط أرسل الرد الذكي المناسب، بدون مقدمة أو تمهيد.
- خلك لبق، ذكي، وردك يعكس الأسلوب المختار، وطوله يتناسب مع طول الرسالة.
رد على الرسالة التالية باللهجة: "$dialect"، وبأسلوب: "$style".
حلل هذه الرسالة: '{message}'
ثم قم بصياغة رد ذكي، باللهجة: '{dialect}'، وبأسلوب: '{style}'.

الشروط:
- لا تستخدم شعر ولا سجع.
- لا تدخل ألفاظ دينية.
- لا تكرر الرسالة.
- رد ذكي، لبق، مركز، بنبرة واضحة.
""".replaceAll('{message}', message).replaceAll('{style}', style).replaceAll('{dialect}', dialect);

    try {
      final res = await http.post(
        Uri.parse('https://api.openai.com/v1/chat/completions'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer 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',
        },
        body: json.encode({
          'model': 'gpt-4',
          'messages': [
            {
              'role': 'user',
              'content': prompt,
            }
          ],
          'temperature': 0.7
        }),
      );

      if (res.statusCode == 200) {
        final data = json.decode(utf8.decode(res.bodyBytes));
        final content = data['choices'][0]['message']['content'];
        setState(() {
          response = content;
        });
      } else {
        setState(() {
          response = 'خطأ في الاتصال بـ GPT: {res.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        response = 'حدث خطأ أثناء الاتصال: {e.toString()}';
      });
    }

    setState(() => isLoading = false);
  }

  Widget _buildChips(List<String> options, String selected, Function(String) onSelected, String customLabel, bool showCustom, Function(bool) toggleCustom, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 8.0,
          children: [
            ...options.map((option) => ChoiceChip(
              label: Text(option),
              selected: selected == option,
              onSelected: (_) {
                toggleCustom(false);
                onSelected(option);
              },
            )),
            ChoiceChip(
              label: showCustom
                  ? SizedBox(
                      width: 120,
                      child: TextField(
                        controller: controller,
                        
decoration: InputDecoration(
  hintText: customLabel,
  filled: true,
  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
  enabledBorder: OutlineInputBorder(
    borderSide: BorderSide(color: Colors.white30),
    borderRadius: BorderRadius.circular(8),
  ),
  focusedBorder: OutlineInputBorder(
    borderSide: BorderSide(color: Colors.white, width: 1.5),
    borderRadius: BorderRadius.circular(8),
  ),
),

                        style: TextStyle(color: Colors.white),
                        onChanged: onSelected,
                      ),
                    )
                  : Text('إدخال جديد'),
              selected: showCustom,
              onSelected: (_) {
                toggleCustom(!showCustom);
                if (!showCustom) {
                  controller.clear();
                  onSelected('');
                }
              },
            ),
          ],
        ),      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('🔥 ولّعها'),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: [
              Text('📩 الرسالة المستلمة:'),
              TextField(
                controller: _messageController,
                maxLines: null,
                
                decoration: InputDecoration(
                  hintText: 'اكتب الرسالة هنا...',
                  filled: true,
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white30),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white, width: 1.5),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
    
              ),
              SizedBox(height: 24),
              Text('🧠 اختر الأسلوب أو أدخل واحد خاص:'),
              _buildChips(styles, selectedStyle, (val) => setState(() => selectedStyle = val),
                  'أدخل أسلوب جديد (اختياري)', showCustomStyleField, (val) => setState(() => showCustomStyleField = val), _customStyleController),
              SizedBox(height: 24),
              Text('🌍 اختر اللهجة:'),
              _buildChips(dialects, selectedDialect, (val) => setState(() => selectedDialect = val),
                  'أدخل لهجة جديدة (اختياري)', showCustomDialectField, (val) => setState(() => showCustomDialectField = val), _customDialectController),
              SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: isLoading ? null : _handleReply,
                icon: Icon(Icons.bolt),
                label: Text('حلل ورد 🔥⚡'),
              ),
              SizedBox(height: 24),
              if (isLoading) Center(child: CircularProgressIndicator()),
              if (!isLoading && response.isNotEmpty)
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey[900],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(response),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
