import 'package:flutter/services.dart';

import 'package:flutter/material.dart';
import '../../components/v1_2/common_card.dart';

class TrendDiscussionScreenV12 extends StatefulWidget {
  const TrendDiscussionScreenV12({Key? key}) : super(key: key);

  @override
  State<TrendDiscussionScreenV12> createState() => _TrendDiscussionScreenV12State();
}

class _TrendDiscussionScreenV12State extends State<TrendDiscussionScreenV12> {
  String trendTitle = "ترند اليوم: #إجازة_نهاية_الأسبوع";
  List<String> discussionStyles = ["ساخر", "جاد", "تحليلي"];
  Map<String, String> generatedTexts = {};

  @override
  void initState() {
    super.initState();
    _generateDiscussions();
  }

  void _generateDiscussions() {
    generatedTexts = {
      "ساخر": "يقال إن الإجازة جت عشان نرتاح، بس الواقع إنها تدريب على الصبر داخل الزحمة 🥲",
      "جاد": "الإجازة تمثل فرصة لإعادة شحن الطاقة، لكنها تتطلب توازن بين الراحة والإنتاجية.",
      "تحليلي": "زيادة التفاعل حول الإجازات يعكس حاجة المجتمع لمرونة أكثر في نمط الحياة الأسبوعي."
    };
    setState(() {});
  }

  Widget _buildDiscussionCard(String style, String text) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Text("أسلوب $style", style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(text),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.copy),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: text));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("تم النسخ"))
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.share),
              onPressed: () {
                // Placeholder for share functionality
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("اشعلها في القروب")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(trendTitle, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ...discussionStyles.map((style) => _buildDiscussionCard(style, generatedTexts[style]!)),
          ],
        ),
      ),
    );
  }
}
