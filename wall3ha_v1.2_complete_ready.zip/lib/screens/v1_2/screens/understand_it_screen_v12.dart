// Understand It Screen - Tone analysis + reply option
