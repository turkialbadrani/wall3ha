// Writer Screen - Already integrated with GPT
