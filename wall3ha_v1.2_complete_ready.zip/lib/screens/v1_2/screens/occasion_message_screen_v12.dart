// Occasion Message Screen - Auto-detect + custom + GPT message
