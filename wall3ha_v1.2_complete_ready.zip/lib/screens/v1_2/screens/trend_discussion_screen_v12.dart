// Trend Discussion Screen - Twitter-like + WhatsApp style
