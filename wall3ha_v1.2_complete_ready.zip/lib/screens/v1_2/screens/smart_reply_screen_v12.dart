// Smart Reply Screen - GPT quick reply based on input
