
import 'package:flutter/material.dart';

class UnderstandItScreenV12 extends StatefulWidget {
  @override
  _UnderstandItScreenV12State createState() => _UnderstandItScreenV12State();
}

class _UnderstandItScreenV12State extends State<UnderstandItScreenV12> {
  final TextEditingController _inputController = TextEditingController();
  String _toneResult = '';
  String _intentionResult = '';
  String _suggestedReply = '';

  void _analyzeText() {
    final text = _inputController.text.trim();
    if (text.isEmpty) return;

    setState(() {
      _toneResult = 'ساخر'; // تمثيل مؤقت
      _intentionResult = 'استفزازي غير مباشر';
      _suggestedReply = 'ممكن ترد عليه بذكاء وتحافظ على صورتك بدون تصعيد.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('افهمها صح')),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: [
              Text('📩 النص المراد تحليله:'),
              TextField(
                controller: _inputController,
                maxLines: null,
                decoration: InputDecoration(
                  hintText: 'ألصق الرسالة هنا...',
                  filled: true,
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: _analyzeText,
                child: Text('حلل النص 🔍'),
              ),
              SizedBox(height: 24),
              if (_toneResult.isNotEmpty) ...[
                _ResultTile(label: 'نبرة النص:', value: _toneResult),
                _ResultTile(label: 'نية الكاتب:', value: _intentionResult),
                _ResultTile(label: 'رد مقترح:', value: _suggestedReply),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  final String label;
  final String value;

  const _ResultTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(label),
      subtitle: Text(value),
    );
  }
}
